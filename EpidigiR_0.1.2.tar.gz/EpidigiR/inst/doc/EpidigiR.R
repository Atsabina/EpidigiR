## -----------------------------------------------------------------------------
# Install required dependencies if not already installed
required_packages <- c("deSolve", "sp", "tm", "glmnet", "caret", "kernlab", "survival")
for (pkg in required_packages) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    install.packages(pkg)
  }
}
# Load required packages
library(deSolve)
library(sp)
library(tm)
library(glmnet)
library(caret)
library(kernlab)
library(survival)
library(EpidigiR)
# Ensure ml_data and clinical_data outcomes are factors for caret models
data(ml_data)
ml_data$outcome <- as.factor(ml_data$outcome)
data(clinical_data)
clinical_data$outcome <- as.factor(clinical_data$outcome)

## -----------------------------------------------------------------------------
data(epi_prevalence)
epi_analyze(epi_prevalence, outcome = "cases", group = "region", type = "summary")

## -----------------------------------------------------------------------------
sir_result <- epi_analyze(data = NULL, outcome = NULL, type = "sir", N = 1000, beta = 0.3, gamma = 0.1, days = 50)
epi_visualize(sir_result, x = "time", y = "Infected", type = "curve", main = "Epidemic Curve")

## -----------------------------------------------------------------------------
data(epi_prevalence)
coordinates(epi_prevalence) <- ~lon+lat
epi_visualize(epi_prevalence, x = "prevalence", type = "map", main = "Prevalence Map")

## -----------------------------------------------------------------------------
data(clinical_data)
epi_model(clinical_data, type = "power", n = 100, effect_size = 0.5, sd = 1)

## -----------------------------------------------------------------------------
data(clinical_data)
epi_model(clinical_data, formula = outcome ~ age + health_score + dose, type = "logistic")

## -----------------------------------------------------------------------------
data(daly_data)
epi_analyze(daly_data, outcome = NULL, type = "daly")

## -----------------------------------------------------------------------------
data(geno_data)
epi_model(geno_data, type = "snp")

## -----------------------------------------------------------------------------
data(survey_data)
epi_analyze(survey_data, outcome = NULL, type = "age_standardize")

## -----------------------------------------------------------------------------
data(ml_data)
epi_model(ml_data, formula = outcome ~ age + exposure + genetic_risk, type = "logistic")

## -----------------------------------------------------------------------------
data(survival_data)
epi_model(survival_data, type = "survival")

## -----------------------------------------------------------------------------
data(nlp_data)
epi_analyze(nlp_data, outcome = NULL, type = "nlp", n = 5)

## -----------------------------------------------------------------------------
data(ml_data)
epi_model(ml_data[, c("age", "exposure", "genetic_risk")], type = "kmeans", k = 3)

## -----------------------------------------------------------------------------
data(ml_data)
epi_model(ml_data, formula = outcome ~ age + exposure + genetic_risk, type = "rf")

## -----------------------------------------------------------------------------
data(ml_data)
epi_model(ml_data, formula = outcome ~ age + exposure + genetic_risk, type = "svmRadial")

## -----------------------------------------------------------------------------
data(diagnostic_data)
epi_analyze(diagnostic_data, outcome = NULL, type = "diagnostic")

## -----------------------------------------------------------------------------
data(clinical_data)
epi_visualize(clinical_data, x = "arm", y = "outcome", type = "boxplot", main = "Outcome by Treatment Arm")

## -----------------------------------------------------------------------------
data(ml_data)
epi_visualize(ml_data, x = "age", y = "outcome", type = "scatter", main = "Age vs. Disease Outcome")

